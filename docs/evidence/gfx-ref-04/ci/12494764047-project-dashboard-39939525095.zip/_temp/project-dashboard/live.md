# Voxelverse – Live-Lieferübersicht

Abgerufen: 2026-10-23T10:30:22+00:00

Offene PRs: **9**. Dies ist kein Fertigstellungsprozentsatz und keine Reservierung.

main: `148ba0bb578e9a01db501444fd11823fa09e8212` · Kandidat #283: `ac2567bda31bdfa6ed8dc974cec7df3d1f8bc0ad` (closed, merged=True).

**Basis hat sich geändert.** Der Integrationsbesitzer muss die feste Statusbewertung abgleichen. Prozentwerte und Abnahmen werden nicht automatisch hochgesetzt.

| PR | Titel | Lieferung | Gestapelt auf | CI am aktuellen Kopf |
|---|---|---|---|---|
| [#293](https://github.com/MajorDragonfly/voxelverse/pull/293) | gfx: natural foliage tones, sky fill and atmospheric depth | Offen | main | Nicht abgefragt |
| [#286](https://github.com/MajorDragonfly/voxelverse/pull/286) | docs: close UI and camera deliveries and record rejected attempts | Offen | main | Nicht abgefragt |
| [#279](https://github.com/MajorDragonfly/voxelverse/pull/279) | \[R33-07 Diagnose Draft\] Geprüfter Sandsturm-QA-Tree und native GL/Forward+-Belege | Entwurf | agent/integration-r33-20261007 | Nicht abgefragt |
| [#278](https://github.com/MajorDragonfly/voxelverse/pull/278) | \[Diagnose, nicht mergen\] R33-06 isolierter Ausrüstungs-/Native-/Kugel-Nachweis | Entwurf | agent/integration-r33-20261007 | Nicht abgefragt |
| [#276](https://github.com/MajorDragonfly/voxelverse/pull/276) | R33-04: isolierte Kameradiagnose, nicht integrieren | Entwurf | agent/integration-r33-20261007 | Nicht abgefragt |
| [#274](https://github.com/MajorDragonfly/voxelverse/pull/274) | QA only: R33-08 publication evidence — Vulkan negative retained | Entwurf | agent/r33-08-forward-publication | Nicht abgefragt |
| [#259](https://github.com/MajorDragonfly/voxelverse/pull/259) | R32-12 evidence runner: real animation states and proposed contact patch | Entwurf | agent/integration-r32-20261002 | Nicht abgefragt |
| [#246](https://github.com/MajorDragonfly/voxelverse/pull/246) | INT30 Diagnose: atomare Flora-Publikationsphasen im Kollisions-Capture | Entwurf | agent/integration-int30-20261001 | Nicht abgefragt |
| [#189](https://github.com/MajorDragonfly/voxelverse/pull/189) | PT17-13: schnellere Stammeskamera und Blicksteuerung auf der Minimap | Offen | main | Nicht abgefragt |

Branch-Abhängigkeiten werden über das PR-Ziel erkannt. Weitere fachliche Abhängigkeiten stehen in der Übergabe. Fehlende PRs beweisen weder freie Arbeit noch eine erfolgte Abnahme.
