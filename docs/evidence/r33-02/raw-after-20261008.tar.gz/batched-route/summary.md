# Movement route

Wall-clock frames; headless/software runs are not target-PC acceptance.
Scene-lifetime maxima identify candidates, not same-frame causality.

| Cycle | Stage | Frames | p50 | p95 | p99 | Max | >33 ms | >50 ms | >100 ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | walk_outward | 374 | 16.6 | 61.2 | 94.6 | 113.3 | 27 | 26 | 1 |
| 0 | walk_return | 404 | 16.6 | 25.4 | 53.4 | 127.1 | 10 | 5 | 2 |
| 1 | walk_outward | 415 | 16.5 | 23.3 | 65.2 | 100.1 | 14 | 8 | 1 |
| 1 | walk_return | 420 | 16.6 | 23.3 | 34.5 | 51.7 | 5 | 1 | 0 |
