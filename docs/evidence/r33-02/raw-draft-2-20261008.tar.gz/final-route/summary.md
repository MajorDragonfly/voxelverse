# Movement route

Wall-clock frames; headless/software runs are not target-PC acceptance.
Scene-lifetime maxima identify candidates, not same-frame causality.

| Cycle | Stage | Frames | p50 | p95 | p99 | Max | >33 ms | >50 ms | >100 ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | walk_outward | 377 | 16.6 | 63.7 | 93.2 | 139.6 | 22 | 22 | 2 |
| 0 | walk_return | 402 | 16.7 | 23.7 | 82.5 | 172.7 | 12 | 9 | 1 |
| 1 | walk_outward | 395 | 16.6 | 29.9 | 86.0 | 124.6 | 17 | 10 | 2 |
| 1 | walk_return | 426 | 16.6 | 22.2 | 32.5 | 109.3 | 4 | 1 | 1 |
