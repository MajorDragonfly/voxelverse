# Movement route

Wall-clock frames; headless/software runs are not target-PC acceptance.
Scene-lifetime maxima identify candidates, not same-frame causality.

| Cycle | Stage | Frames | p50 | p95 | p99 | Max | >33 ms | >50 ms | >100 ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | walk_outward | 396 | 16.6 | 48.5 | 86.9 | 108.8 | 20 | 19 | 2 |
| 0 | walk_return | 418 | 16.7 | 21.1 | 64.3 | 95.8 | 11 | 11 | 0 |
| 1 | walk_outward | 406 | 16.6 | 27.2 | 60.6 | 125.2 | 15 | 8 | 1 |
| 1 | walk_return | 431 | 16.4 | 22.8 | 31.6 | 41.6 | 4 | 0 | 0 |
