# Movement route

Wall-clock frames; headless/software runs are not target-PC acceptance.
Scene-lifetime maxima identify candidates, not same-frame causality.

| Cycle | Stage | Frames | p50 | p95 | p99 | Max | >33 ms | >50 ms | >100 ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | walk_outward | 321 | 16.6 | 77.5 | 130.5 | 204.8 | 32 | 29 | 7 |
| 0 | walk_return | 434 | 16.6 | 20.4 | 25.3 | 32.3 | 0 | 0 | 0 |
| 1 | walk_outward | 400 | 16.7 | 22.9 | 82.2 | 146.9 | 13 | 7 | 3 |
| 1 | walk_return | 432 | 16.7 | 21.4 | 28.3 | 62.1 | 2 | 1 | 0 |
