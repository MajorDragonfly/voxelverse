import json, os, pathlib, socket, subprocess, sys, time

workspace = pathlib.Path('/workspace/scratch/80e56bd010c5')
project = workspace / 'clone-attempt'
sys.path.insert(0, str(project / 'tools'))
from validation_provenance import SourceRun

output = workspace / 'native-2ec14bbd'
output.mkdir(exist_ok=True)
source = SourceRun(project)
source.begin_report(output)
env = dict(os.environ)
env.update(DISPLAY='127.0.0.1:182', LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='2')
env['LD_LIBRARY_PATH'] = str(workspace / 'native-deps/usr/lib/x86_64-linux-gnu')
engine = str(workspace / 'engine/editor/Godot_v4.6.3-stable_linux.x86_64')
commands = [
    ('medieval', ['civilization/technology/run_preview.py', '--verify', '--capture', '--renderer', 'gl_compatibility']),
    ('owned', ['tools/review_int30_owned_animals.py']),
    ('shipyard', ['tools/review_shipyard_presentation.py', '--capture', '--authoring-profile']),
    ('journal', ['tools/review_journal_localization.py']),
    ('book', ['tools/review_r32_13_book.py']),
    ('pause', ['tools/review_pause_menu.py']),
    ('combined', ['tools/review_int30_menu_audio_book.py']),
    ('book-host', ['tools/review_int30_menu_audio_book.py', '--book-frames']),
]
# The full supplied CI flows already have original successful artifacts on the
# prospective R33 merge. Only these missing 150% layout captures are local.
commands = [entry for entry in commands if entry[0] in {'owned', 'journal', 'book'}]
results = []
with (output / 'xvfb.log').open('w') as log:
    display = subprocess.Popen([str(workspace / 'native-deps/usr/bin/Xvfb'), ':182', '-screen', '0', '1920x1080x24', '-nolisten', 'unix', '-nolisten', 'local', '-listen', 'tcp', '-ac'], env=env, stdout=log, stderr=subprocess.STDOUT)
    try:
        for _ in range(40):
            try:
                with socket.create_connection(('127.0.0.1', 6182), timeout=0.2): break
            except OSError:
                if display.poll() is not None: raise RuntimeError('Xvfb terminated')
                time.sleep(0.1)
        else: raise RuntimeError('Own native display unavailable')
        for name, arguments in commands:
            command = [sys.executable, *arguments, '--godot', engine, '--output', str(output / name)]
            print('NATIVE_START', name, json.dumps(command), flush=True)
            start = time.monotonic()
            with (output / (name + '-console.log')).open('w') as log:
                result = subprocess.run(command, env=env, cwd=project, stdout=log, stderr=subprocess.STDOUT)
            record = {'name': name, 'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3), 'command': command}
            results.append(record)
            print('NATIVE_END', json.dumps(record), flush=True)
            source.observe(name, force=True)
            if result.returncode != 0: break
    finally:
        display.terminate()
        display.wait(timeout=10)
        provenance = source.write_report(output)
        (output / 'native-results.json').write_text(json.dumps({'source': provenance, 'results': results}, indent=2) + '\n')
sys.exit(0 if len(results) == len(commands) and all(r['exit_code'] == 0 for r in results) and provenance['reusable'] else 1)
