import json, pathlib, subprocess, sys

base = pathlib.Path('/workspace/scratch/80e56bd010c5')
project = base/'clone-attempt'
engine = str(base/'engine/editor/Godot_v4.6.3-stable_linux.x86_64')
result = subprocess.run([sys.executable,str(base/'native_run.py')],cwd=project)
if result.returncode: sys.exit(result.returncode)
tests = json.loads((base/'check-03-cb/results.json').read_text())['selected_tests']
command = [sys.executable,'tools/validate_godot.py','--godot',engine,'--output',str(base/'check-final-2ec14bbd'), '--skip-import','--skip-main','--tests',*tests]
print('FINAL_FOCUSED_START',json.dumps(command),flush=True)
sys.exit(subprocess.run(command,cwd=project).returncode)
