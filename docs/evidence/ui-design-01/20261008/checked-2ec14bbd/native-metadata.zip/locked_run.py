import fcntl, json, pathlib, subprocess, sys, platform
locks = []
for name in ['/tmp/voxelverse-heavy.lock', '/tmp/voxelverse-r32-db514e109ac6-heavy.lock']:
    stream = open(name, 'a+')
    try:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print('HEAVY_LOCK_BUSY', name, flush=True)
        sys.exit(73)
    locks.append(stream)
engines=[]
for d in pathlib.Path('/proc').iterdir():
    if not d.name.isdigit(): continue
    try:
        args=(d/'cmdline').read_bytes().split(b'\0')
        if pathlib.Path(args[0].decode(errors='replace')).name.lower().startswith('godot'):
            engines.append(d.name)
    except OSError: pass
if engines:
    print('FOREIGN_ENGINE_BUSY', engines, flush=True)
    sys.exit(74)
print('HOST_START', platform.node(), json.dumps(sys.argv[1:]), flush=True)
try:
    result=subprocess.run(sys.argv[1:])
finally:
    print('HOST_END', platform.node(), flush=True)
sys.exit(result.returncode)
