extends "res://tests/owned_animal_localization_test.gd"

func _image(label: String) -> void:
	await super._image(label)
	if "800x600" not in label: return
	print("OWNED_NATIVE_GEOMETRY ", label, " window=", root.size, " visible=", root.get_visible_rect(), " final=", root.get_final_transform(), " panel=", _physical(journal._panel), " title=", _physical(journal._heading_title), " minimum=", journal._panel.get_combined_minimum_size(), " heading_font=", journal._heading_title.get_theme_font_size("font_size"))
