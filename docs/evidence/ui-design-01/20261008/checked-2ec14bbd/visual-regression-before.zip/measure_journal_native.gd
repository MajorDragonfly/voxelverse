extends "res://tests/journal_localization_test.gd"

func _image(label: String) -> void:
	await super._image(label)
	if "800x600" not in label: return
	print("JOURNAL_NATIVE_GEOMETRY ", label, " heading=", _physical(journal._heading), " title=", _physical(journal._heading_title), " title_min=", journal._heading_title.get_combined_minimum_size(), " text=", journal._heading_title.text)
