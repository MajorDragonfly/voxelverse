import argparse, json, os, pathlib, socket, subprocess, sys, tempfile, time
workspace = pathlib.Path('/workspace/scratch/80e56bd010c5')
project = workspace / 'clone-attempt'
sys.path.insert(0, str(project / 'tools'))
from validation_support import isolated_env, validation_editor
from validation_provenance import SourceRun
parser = argparse.ArgumentParser()
parser.add_argument('--godot', required=True)
parser.add_argument('--output', type=pathlib.Path, required=True)
args = parser.parse_args()
output = args.output.resolve()
output.mkdir(exist_ok=False)
source = SourceRun(project)
source.begin_report(output)
env = dict(os.environ)
env.update(DISPLAY='127.0.0.1:181', LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='2', LD_LIBRARY_PATH=str(workspace/'native-deps/usr/lib/x86_64-linux-gnu'))
with (output/'xvfb.log').open('w') as log:
    display = subprocess.Popen([str(workspace/'native-deps/usr/bin/Xvfb'), ':181', '-screen','0','1920x1080x24','-nolisten','unix','-nolisten','local','-listen','tcp','-ac'],env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        for _ in range(40):
            try:
                with socket.create_connection(('127.0.0.1',6181),timeout=.2):break
            except OSError:
                if display.poll() is not None:raise RuntimeError('Own display terminated')
                time.sleep(.1)
        else:raise RuntimeError('Own display unavailable')
        with validation_editor(args.godot) as editor, tempfile.TemporaryDirectory(prefix='owned-geometry-') as temp:
            runtime_env = isolated_env(pathlib.Path(temp))
            runtime_env.update(env)
            for key in ['XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME','APPDATA','LOCALAPPDATA']:
                runtime_env[key] = str(pathlib.Path(temp)/key.lower())
            command = [str(editor),'--path',str(project),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--script',str(workspace/'measure_owned_native.gd'),'--','--browser-capture','--capture',str(output)]
            with (output/'render.log').open('w') as log:
                result = subprocess.run(command,env=runtime_env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
            source.observe('instrumented original owned flow',force=True)
            provenance = source.write_report(output)
            (output/'results.json').write_text(json.dumps({'exit_code':result.returncode,'command':command,'source':provenance,'scope':'Original localization/browser input flow with external geometry logging; no replacement acceptance'},indent=2)+'\n')
    finally:
        display.terminate()
        display.wait(timeout=10)
sys.exit(result.returncode)
