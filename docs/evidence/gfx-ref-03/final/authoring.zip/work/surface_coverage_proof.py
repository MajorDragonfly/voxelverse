"""Compare exact exposed voxel tiles, normals and slots, allowing AO splits."""
from pathlib import Path
import hashlib,json,struct,subprocess
repo=Path(__file__).resolve().parents[1]/'voxelverse'
base='a8d19667d88e0c095eb8e238cdaff6aee10c8992'
metrics='assets/packs/temperate_forest_v1/environment/benchmark_v2/benchmark_metrics.json'
old=json.loads(subprocess.check_output(['git','-C',str(repo),'show',base+':'+metrics]));new=json.loads((repo/metrics).read_text())
def streams(data):
 n=struct.unpack_from('<I',data,12)[0];d=json.loads(data[20:20+n]);b=data[28+n:];p=d['meshes'][0]['primitives'][0]
 def values(i,size):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];offset=v.get('byteOffset',0)+a.get('byteOffset',0)
  return list(struct.iter_unpack('<'+'f'*size,b[offset:offset+a['count']*size*4]))
 return values(p['attributes']['POSITION'],3),values(p['attributes']['NORMAL'],3),values(p['attributes']['TEXCOORD_0'],2)
def tiles(data,step):
 positions,normals,uvs=streams(data);result=set();area=0
 for i in range(0,len(positions),4):
  q=[tuple(round(n/step) for n in p) for p in positions[i:i+4]];normal=normals[i];axis=next(a for a in range(3) if normal[a]);u,v=(axis+1)%3,(axis+2)%3
  assert all(normals[j]==normal and uvs[j]==uvs[i] for j in range(i,i+4))
  plane=q[0][axis];assert all(p[axis]==plane for p in q)
  low_u,high_u=min(p[u] for p in q),max(p[u] for p in q);low_v,high_v=min(p[v] for p in q),max(p[v] for p in q)
  slot=int(uvs[i][0]*32);area+=(high_u-low_u)*(high_v-low_v)
  for a in range(low_u,high_u):
   for b in range(low_v,high_v):result.add((axis,int(normal[axis]),plane,slot,a,b))
 assert len(result)==area,'overlapping exposed tiles'
 return result
records=[]
for family,variants in new.items():
 for index,entry in enumerate(variants):
  suffix='' if entry['variant']==0 else '_species'+str(entry['variant'])
  path='assets/packs/temperate_forest_v1/environment/benchmark_v2/'+family+suffix+'_'+entry['lod']+'.glb'
  before=subprocess.check_output(['git','-C',str(repo),'show',base+':'+path]);after=(repo/path).read_bytes()
  a,b=tiles(before,entry['voxel_size']),tiles(after,entry['voxel_size']);assert a==b,path
  previous=old[family][index];assert all(previous['bounds'][k]==entry['bounds'][k] for k in ['min','max']) and previous['filled_voxels']==entry['filled_voxels']
  records.append({'path':path,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'exact_exposed_tiles':len(a),'triangles_before':previous['triangles'],'triangles_after':entry['triangles']})
sources=[]
for p in sorted((repo/'art/source/blockbench/environment/benchmark_v2').glob('*.bbmodel')):
 path=str(p.relative_to(repo));a=json.loads(subprocess.check_output(['git','-C',str(repo),'show',base+':'+path]));b=json.loads(p.read_text());b['voxelverse'].pop('ambient_occlusion',None);assert a==b,path;sources.append(path)
report={'passed':True,'base':base,'meshes':len(records),'sources':len(sources),'proof':'Exact exposed voxel tiles, face normals, semantic slots, bounds and filled voxels; all editable source content exact excluding AO opt-in. AO-aware subdivisions intentionally change vertex/index streams.','triangles_before':sum(x['triangles_before'] for x in records),'triangles_after':sum(x['triangles_after'] for x in records),'records':records,'editable_sources':sources}
out=repo.parent/'work/surface-coverage-final.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['records','editable_sources']}))
