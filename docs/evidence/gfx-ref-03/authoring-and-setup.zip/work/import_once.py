import sys,subprocess,tempfile,json
from pathlib import Path
repo=Path(__file__).resolve().parents[1]/'voxelverse'
sys.path.insert(0,str(repo/'tools'))
from validation_support import isolated_env,validation_editor
binary=repo.parent/'toolchain/editor/Godot_v4.6.3-stable_linux.x86_64'
with validation_editor(str(binary)) as editor,tempfile.TemporaryDirectory(prefix='gfx03-import-') as tmp:
 command=[str(editor),'--headless','--path',str(repo),'--import']
 print(json.dumps({'command':command}),flush=True)
 result=subprocess.run(command,env=isolated_env(Path(tmp)),timeout=180)
 raise SystemExit(result.returncode)
