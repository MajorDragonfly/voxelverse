import hashlib, json, struct, subprocess, sys
from pathlib import Path
ROOT=Path('/workspace/scratch/bac0d501b6e8/gfx-ref-03/voxelverse')
WORK=Path(__file__).resolve().parent
def stream(doc,binary,index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];start=v.get('byteOffset',0)+a.get('byteOffset',0);n=a['count']*{'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]*{5121:1,5125:4,5126:4}[a['componentType']]
 return hashlib.sha256(binary[start:start+n]).hexdigest()
manifest=json.loads((ROOT/'assets/packs/temperate_forest_v1/manifest.json').read_text());records={}
for entry in manifest['assets']:
 if 'benchmark' not in entry.get('tags',[]):continue
 for variant,tiers in entry['geometry_variants'].items():
  for tier,path in tiers.items():
   path=path.removeprefix('res://');raw=(ROOT/path).read_bytes();n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);binary=raw[28+n:];p=doc['meshes'][0]['primitives'][0]
   records[path]={s:stream(doc,binary,p['attributes'][s]) for s in ['POSITION','NORMAL','TEXCOORD_0']};records[path]['indices']=stream(doc,binary,p['indices'])
 for source in entry['variant_sources'].values():
  raw=json.loads((ROOT/source).read_text());raw['voxelverse'].pop('ambient_occlusion',None);records[source]={'editable_voxels':hashlib.sha256(json.dumps(raw,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
out=WORK/'geometry-before.json'
if sys.argv[1]=='before':
 assert not out.exists();out.write_text(json.dumps(records,indent=2)+'\n');print('Captured63mesh streams and21editable sources before baking.')
else:
 before=json.loads(out.read_text());assert records==before
 (WORK/'geometry-equivalence.json').write_text(json.dumps(dict(base='a8d19667d88e0c095eb8e238cdaff6aee10c8992',base_tree='d31860a0ed3a13f8a6c0c77a95d8f79fda212b97',passed=True,meshes=63,sources=21,proof='All position, normal, semantic UV and triangle-index streams byte-identical; editable cube/source content identical excluding the opt-in AO metadata.',records=records),indent=2)+'\n')
 print('All63geometry streams and21editable sculptures unchanged.')
