import sys,fcntl,subprocess,json,socket
from contextlib import ExitStack
from pathlib import Path
repo=Path(__file__).resolve().parents[1]/'voxelverse'
sys.path.insert(0,str(repo/'tools'))
from review_r32_06_campaign_light import godot_processes
with ExitStack() as stack:
 for path in ['/tmp/voxelverse-heavy.lock','/tmp/voxelverse-r32-db514e109ac6-heavy.lock']:
  f=stack.enter_context(open(path,'a+'));fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 processes=godot_processes();print(json.dumps({'host':socket.gethostname(),'before_godot_processes':processes,'locks':'both','command':sys.argv[1:]}),flush=True)
 if processes:raise SystemExit('Foreign Godot process; no launch')
 result=subprocess.run(sys.argv[1:])
 print(json.dumps({'after_godot_processes':godot_processes(),'exit_code':result.returncode}),flush=True)
 raise SystemExit(result.returncode)
