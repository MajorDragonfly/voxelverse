#!/usr/bin/env python3
import os, sys
engine = "/workspace/scratch/2c2866d70564/godot"
arguments = sys.argv[1:]
if "res://tests/settlement_runtime_test.gd" in arguments:
    arguments.extend(["--", "--slow-settlement-work"])
os.execv(engine, [engine, *arguments])
