# Collision capture run 36824683412: bounded read-only diagnosis

Examined source commit `74bbcbcf9854cd35eb0c816f95a65ad17d2e2dfe`, tree `a1a53c20730b1000e703ff1add4dd854fcdb069a`. No source edits or reruns performed.

## Preserved evidence

- Forward+ job `110247626277` fails in Capture physical campaign sweeps; GL job `110247626028` passes.
- Forward artifact `/workspace/scratch/4cf151b8748e/attachments/a724230b-fff9-40aa-924a-ae8594377bb2/int30-collision-forward_plus-failed.zip`, API/local SHA256 `66ff6b5da020b10f2ae8b71dbb25670f82d9ada353765a5745e65b42aa088f92`.
- GL artifact `/workspace/scratch/4cf151b8748e/attachments/5d81645f-05b9-46f0-94ca-aaf9662ca107/int30-collision-gl-passed.zip`, API/local SHA256 `a3ec2c6e8c0c489a32c9678855318fa95813e06bef7abbf5292b5a88f2e46c06`.
- Exact engine logs are in `ci245-collision-forward-artifact/run.log` (SHA256 `a037a19037fd575e99655fba777cebc4d9afefc818bf9e5e3e21369c4ad12897`) and `ci245-collision-gl-artifact/run.log` (SHA256 `aa1e1207cebf1a3756bb48ec2da3ee359939566ede7ef74d0af61b59c61291ca`). Whole job logs also preserved as `ci245-collision-forward-110247626277.log` and `ci245-collision-gl-110247626028.log`.
- Both start/end full manifests are clean and stable, source SHA256 `c06aed81737a973930f8969b922ac183585dc25dad3ff2dfc8e46f09f0c36ae5`, 5400 files. Forward provenance is reusable=false because the run failed, not because source changed.

## Definite failure and limits

The Python helper's unchanged 360-second engine process guard expires (exit124). Forward logs list only bush, rock, pine at targets-ready. Therefore `tools/int30_scenery_collision_probe.gd:31` has already recorded the failing assertion `Canonical seed did not publish all four solid families`. It is deferred in the failures array until `_finish`; process timeout prevents its normal printing. The native branch executes CPU/GPU transform equality assertions, but their outcomes are not individually printed either.

The three published families complete 9 near/rebase motion checks with positive contacts: bush19/1/1, rock21/1/1, pine18/1/1. Positive contacts prove those recorded collision motions did stop. Their ray/rebase/transform assertions are deferred; absence of printed errors does not prove every assertion passed. Oak is absent and no returned sweeps run. There is no final world JSON or marker. This is incomplete collision acceptance, not demonstrated terrain pass-through.

After the ninth check, control flow is: weak-ref retirement <=2s (lines66-69), far publication wait <=90s (70), snapshot, move back, return publication wait <=90s (74), then returned sweeps. There are no stage prints or checkpoint writes between these awaits. The existing log cannot identify far versus return as the exact active wait. The earliest long wait after the final logged check is the far wait. No strict-filter or budget change can resolve that observability gap.

## Wall time versus physical/capture states

The job launches at06:26:20.347Z (Forward) and06:26:16.856Z (GL). Python first hashes the complete source before starting the engine; the engine's 360s guard is not the complete job-step time.

| Measurement | Forward+ | GL |
| --- | ---: | ---: |
| SPHERE_LOAD |63.558s|44.165s|
| First saved bush state (ZIP mtime, 2s precision)|06:29:12Z|06:27:20Z|
| Bush state0 to29|~38s|~14s|
| Rock state0 to29|~38s|~14s|
| Pine state0 to29|~30s|~14s|
| All recorded-family state span|~112s for3 families|~58s for4 families|
| Final saved state|06:31:04Z|06:28:18Z|
| Engine log close/guard|06:32:22Z|06:28:50Z|

Each near capture executes exactly30 `physics_frame` waits/motions and30 explicit force_draw/readback/PNG writes. Each rebase/returned sweep executes1 motion. Encoded videos play those states at10fps; their3s duration is neither simulation elapsed time nor wall rendering speed. The project leaves physics tick rate at the engine default and uses Jolt. Actual physics frame counters/elapsed simulation time are not recorded, so nominal timestep multiplication would not prove actual scheduling.

GL records initial/far/return/final publication waits4.359/18.081/5.033/3.315s, each25 patches, max_publish_units1, no workers/prepared/staged remaining at wait completion. GL's final180 samples of the coarse physics monitor are median8.483ms, p95/max8.616ms; these are a separate final steady-state sample, not capture readback wall time. All16 GL ray/motion cases pass and all4 videos exist.

Forward's first PNG arrives about172s after the helper invocation, about108s after its reported sphere load. The home-controls wait is at most12s and the first publication wait is at most90s. This is consistent with the first publication wait timing out, then querying incomplete published targets and starting slow native capture. It remains an inference because `_targets`, first native draw, process overshoot, and the wait result have no timestamps/checkpoint. Roughly78s remain after the last PNG before the process guard; that is consistent with waiting for far publication, but also cannot rule out later return preparation.

## Source inspection

- Publication is deliberately paced by process frames: one near MultiMesh/shape per frame (`surface_ecosystem.gd:60-110,227-307`). Distant scenery reserves near publication frames at priority-1 (`surface_distant_scenery.gd:26-29,56-65,92-126`). Cold imported art is also one load per process frame (`authored_environment_assets.gd:20-40`). Software Vulkan native force_draw/readback has materially greater wall cost in the preserved capture frames. These mechanisms make scheduler/renderer variability plausible; they do not establish host load as the sole cause or identify a production defect.
- The wait predicate's missing explicit prepared flag does not reveal a concrete false-completion bug: completed-worker preparation is immediately consumed in the same `_tick`, and publication attaches a complete patch only at its final step. No await separates wanted replacement/removal in `_refresh`. No speculative production guard warranted.
- Canonical placement RNG uses body.seed and cell coordinates, not random body IDs (`surface_population_job.gd:54`); the differing generated body IDs in these two runs alone do not explain missing oak. The failing artifact lacks initial cell keys/player address and wait diagnostics, so a changed neighborhood or incomplete publication cannot be distinguished conclusively.

## Exact next action

After the other native queue drains, perform **one rerun of only the original failed Forward+ job of run36824683412**, preserving its pinned74bb head/workflow, Godot4.6.3, Mesa software Vulkan, 960x540, --disable-render-loop, --capture, identical helper command and all360s/90s/2s guards/strict filters. Retain the original attempt/artifact alongside the new one. Do not rerun the successful GL job. A successful rerun must include4 canonical families,4 complete30-state videos, the complete16 near/rebase/returned checks, final JSON/marker, clean stable exact-source evidence and no failures.

If that identical rerun fails again, the limited next owner change is diagnostics only: print/checkpoint each publication wait's stage, Time.get_ticks_msec, Engine.get_process_frames/get_physics_frames, initial/wanted/published cell keys/player address, near streaming_diagnostics and distant diagnostics; print recorded assertions immediately and checkpoint partial evidence before capture/far/return. Separate force_draw/readback/PNG wall durations from physical steps. Keep all existing assertions, routes, guards and production publication behavior. This yields the exact blocked phase/counter without a speculative generation fix or relaxed acceptance.

## Single unchanged repeat: failed again

Root initiated exactly one rerun of the failed job. New job `110254636934` completed failure at06:57:22Z. Capture helper command is identical apart from its temporary editor path. New artifact `11145857345`,3164475bytes, locally/API-verified SHA256 `e8dcba1f9ef01f8f555bb59be5513670f0271437d353590373818905cc21b3e0` is preserved at `/workspace/scratch/4cf151b8748e/attachments/73788156-9320-46e4-96c4-078f4a254d4a/int30-collision-forward_plus-repeat-failed.zip`, extracted into `ci245-collision-forward-repeat-artifact`. Exact engine `run.log` SHA256 is `db511130544358be2e4558771d3f71234dbc692f60a4a15c9bbba37cc7e6af20`; whole job log is `ci245-collision-forward-repeat-110254636934.log`. Original archives/logs remain intact and both old/new artifacts still appear in the API.

Verified new artifact's start and end: exact74bb commit/treea1a53c, same full source digestc06aed81737a973930f8969b922ac183585dc25dad3ff2dfc8e46f09f0c36ae5, complete5400-file manifests, clean worktree, stable provenance; reusable=false. Again passed=false/exit124, no final marker/JSON, only3 videos, missing oak at targets-ready, and the exact same9 near/rebase contact counts19/1/1,21/1/1,18/1/1. Deferred ray/rebase/transform assertions still cannot be individually accepted from the partial artifact.

| Repeat comparison | Original Forward+ | Single repeat |
| --- | ---: | ---: |
| SPHERE_LOAD|63.558s|64.401s|
| Helper invocation|06:26:20.347Z|06:51:15.292Z|
| First bush state|06:29:12Z|06:54:14Z|
| Time invocation to first state|~172s|~179s|
| Bush state0 to29|~38s|~36s|
| Rock state0 to29|~38s|~40s|
| Pine state0 to29|~30s|~30s|
| Recorded state span|~112s|~114s|
| Last pine state|06:31:04Z|06:56:08Z|
| Engine guard/log close|06:32:22Z|06:57:18Z|

The drained-queue repeat closely reproduces the missing family and timing pattern. It is **not** evidence for a transient host-load-only explanation. There is still no independently demonstrated source mechanism that makes oak generation impossible or a proven collision pass-through; the repeated native preparation/capture failure is a real unresolved acceptance blocker. No second retry is proposed or performed. The concrete next owner task is the diagnostics-only phase/checkpoint patch specified above, followed by a separately identified diagnostic run that retains all production behavior, routes, assertions and existing budgets. That instrumented source would have its own source hash; it must not be reported as an unchanged74bb repeat.
