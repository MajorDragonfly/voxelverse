extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	# Exercise only diagnostic completion/atomic writes, without opening a world.
	var probe := preload("res://tools/int30_scenery_collision_probe.gd").new()
	probe.tree = self
	probe._diagnostic_started_usec = Time.get_ticks_usec()
	probe.evidence = {"schema": 2, "complete": false, "passed": false, "status": "incomplete",
		"phase_records": [], "capture_frames": [], "dropped_phase_records": 0}
	probe._route_complete = not "--incomplete" in OS.get_cmdline_user_args()
	probe._checkpoint("fixture")
	var progress: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(probe.PROGRESS_PATH))
	if progress.complete != false or progress.passed != false:
		push_error("A diagnostic checkpoint became complete/successful")
		probe.free()
		quit(2)
		return
	await probe._finish()
	var final: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("user://int30-collision-world.json"))
	var expected: bool = probe._route_complete
	if not has_meta(&"runtime_finishing") or final.complete != expected or final.passed != expected:
		push_error("Final evidence was not committed after shared shutdown")
		probe.free()
		quit(2)
		return
	print("DIAGNOSTIC_LIFECYCLE_PASSED complete=", expected)
	probe.free()
