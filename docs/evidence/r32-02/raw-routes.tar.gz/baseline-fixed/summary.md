# Movement route

Wall-clock frames; headless/software runs are not target-PC acceptance.
Scene-lifetime maxima identify candidates, not same-frame causality.

| Cycle | Stage | Frames | p50 | p95 | p99 | Max | >33 ms | >50 ms | >100 ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | walk_outward | 322 | 16.7 | 77.9 | 128.8 | 214.1 | 36 | 28 | 9 |
| 0 | walk_return | 434 | 16.6 | 21.1 | 25.8 | 48.0 | 1 | 0 | 0 |
| 1 | walk_outward | 393 | 16.7 | 32.1 | 81.9 | 176.0 | 17 | 8 | 3 |
| 1 | walk_return | 426 | 16.6 | 22.7 | 34.0 | 51.2 | 5 | 1 | 0 |
