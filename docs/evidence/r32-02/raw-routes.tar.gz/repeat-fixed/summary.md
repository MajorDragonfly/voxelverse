# Movement route

Wall-clock frames; headless/software runs are not target-PC acceptance.
Scene-lifetime maxima identify candidates, not same-frame causality.

| Cycle | Stage | Frames | p50 | p95 | p99 | Max | >33 ms | >50 ms | >100 ms |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | walk_outward | 331 | 16.7 | 71.4 | 127.4 | 223.4 | 35 | 29 | 7 |
| 0 | walk_return | 422 | 16.7 | 23.7 | 32.2 | 57.2 | 4 | 1 | 0 |
| 1 | walk_outward | 388 | 16.7 | 29.5 | 112.1 | 170.8 | 13 | 9 | 4 |
| 1 | walk_return | 434 | 16.6 | 19.5 | 22.9 | 27.6 | 0 | 0 | 0 |
